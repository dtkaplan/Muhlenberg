---
title: "A Course-Support Package"
author: "Danny Kaplan"
date: "2015-02-06"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{package YourCourse}
  %\VignetteEngine{knitr::rmarkdown}
  \usepackage[utf8]{inputenc}
---

This is an experiment in helping instructors to organize their class materials into an R package.  Packages are the standard way of distributing software, data, and documentation contributed to the R system.  This package is aimed at those who know little or nothing about writing an deploying an R package.

## What you can use this for

By making trivial modifications to the package you can:

* arrange that your students need go only load one package, which in turn will install and load any others you specify.
* specify one or more web server addresses where you can place data and documents, and provide easy access to those files through the `our_file()` and `edit_web_file()` functions.
* make it easy to create collaborative shared documents containing R statements, Rmd, or indeed, any text you like.  You and your students can edit these documents simultaneously, then bring them into R easily.
* provide one or more Rmd templates suited for your course that 
    * embed the Rmd text as a link in the HTML file, so that the Rmd is always connected the compiled document.
    * contain the "boilerplate" (e.g. package loading) that students need in their files but often forget.

[In DRAFT] Are there other such logistical services you would like the package to provide?

* Quick updating?



## Customizing the package for your course.

Get the "source" files for the package.  These are packed into the same file you used to install the package. Unpack it.  Then, in RStudio, open the `CourseR.Rproj` project.  This gives you access to the files you need and sets things up for building and distributing your customized package later on.

Unzip the package file to reveal several directories and files.

Within RStudio or another editor, open and modify these files. 

* `DESCRIPTION`. The first line in the `DESCRIPTION` file starts with
```
    package: YourCourse
```
Change `YourCourse` to something specific to your course or set of courses. It should be one word and can contain numbers, but no punctuation. It should be be different from the name of any other packages used in your course. Suggested forms: `Stats101`, `KenyonMath`, or the last name of the instructor.  If you have multiple courses, I suggest creating one package for all of them.  If you work with other instructors, I suggest sharing a package (e.g. named `KenyonMath`) with them.

* In file `R/our_file.R`, change the value of the `.ourWebServers` variable to be the URLs for web sites where you will place your materials.  These could be university run servers, your own personal web site, Dropbox public folders, Google Doc shared directories, etc.

The URL you install should be the complete path name to the directory where you will place your files, e.g. `"http://www.macalester.edu/~kaplan/courseFiles/"`. It should end with a `/`, since this is a path address rather than a file name.  You can specify multiple servers.  They will be searched from first to last.  Name conflicts among the servers will be resolved in favor of earlier entries in `.ourWebServers`.

* For collaborative editing, open the `R/collaborate.R` file and change the default for the `project=` argument that is something likely to be unique to your courses, e.g., `AmherstStats`.  Even better, you may want to set up your own account on FireBase.  The ID for that account, e.g. `mosaic-web` should be used as the `group=` argument to the `collaborate()` function.  There's a bandwidth limitation on each account, so setting up and using your own account on Firebase will avoid any problem due to bandwidth.

* There is an R/Markdown template directory in `inst/rmarkdown/templates/`.  If you want more than one template available throught this package, you can copy over any of the existing template directories.  Then, edit two things in the directory for the template you are customizing.

* Edit the `template.yaml` file --- it's plain text --- to set the `name:` field to the name of your package and the `description:` field to give whatever information about the template you like.  (You can leave it alone if you like.)
* Edit the `skeleton/skeleton.Rmd` file to change the package named as the argument to `library()` to be the name of your package.  You can also make any other modifications that you like.  But make sure that the resulting Rmd file compiles successfully.

If you make multiple templates, they should be for different types of documents, e.g. Lab Write-Up, Final Report (in PDF), etc.
It's best not to make a template for each assignment, etc.  Instead, post the Rmd file that you want to use as the template for that assignment to your web server and have the students use `edit_web_file()` function to access that document.

## Upload your course files to the server

You can do this at any point, before or after you customize the package.  Simply copy over the files you want to provide access to to the appropriate directory in your server.

You can create sub-directories within the server.  For instance, in `http://www.macalester.edu/~kaplan/` I might create subdirectories `Stats253` or `Math155/WeeklyAssignments/`.

Once the files are there, your students need only load the package you're creating and give statements like
```r
edit_web_file("Math155/WeeklyAssignments/Week-3.Rmd")
HousingPrices <- our_file("Stats253/Data/saratoga_houses.csv")
# ... and so on.
```

## Building the Package.

In the "Build" tab in RStudio, press the "Check" button. A lot of messages will be given.  For now, ignore these.  What you're looking for at the bottom is `R CMD check succeeded`.  If you don't see that, scan back through the earlier messages to see if any of them suggest where the problem might be.  But don't worry about it too much.

Then, select "Build/More/Build Source Package". Again, many messages will appear, but at the end you'll see: "Source package written to YourCourse_0.1.tar.gz".  Instead of `YourCourse` the name will reflect the one you specified in the `DESCRIPTION` file.

## Distributing your package

Upload the package file (the file ending in `.tar.gz`) to a directory on any convenient web server, for instance, `http://www.macalester.edu/~kaplan/CourseFiles/` If you use Dropbox or similar facilities, you may use the web link provided by those facilities.

Give your students these instructions to be executed in their own R session, of course substituting your own web address and the name of the `.tar.gz` file that you created.

```r
install.packages("devtools")
library(devtools)
install_url("http://www.macalester.edu/~kaplan/CourseFiles/YourCourse_0.1.tar.gz")
```

You may want to provide these lines on a web page so students can simply cut-and-paste them into R.


library(knitr)
knit(input='vignettes/customizing.Rmd', output='inst/doc/customizing.md')
library(markdown)
markdownToHTML('inst/doc/customizing.md', 'inst/doc/customizing.html')

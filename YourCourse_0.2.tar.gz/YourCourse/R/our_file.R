#' read data from the course repository
#'
#' @title Get file contents from course repository
#' @description Utility function to read data from any of a previously defined set
#' of repositories.  These repositories are defined when the package is
#' built.
#' @name our_file
#'
#' @aliases edit_web_file, our_file


#' @param file Name of file relative to repository --- character string
#' Can be data or R code or Rmd.  If it's a CSV or text file, the next two parameters apply
#' @param header=TRUE -- is there a header on a CSV data file
#' @param na.strings -- identifiers for NA in CSV file
#'
#' @export
our_file <- function(file, header=TRUE,
                     na.strings=c("NA","",".","na", "-")){

  # Customization: Put your course web addresses here ending in /
  .ourWebServers <- c("http://www.mosaic-web.org/go/datasets/",
                      "dtkaplan.github.io/Muhlenberg/")

  # Figure out what kind of file it is.
  # This code is also in editWebFile.R, so abstract it out!
  partsOfName <- stringr::str_match_all(file,
                                        "(^.+)(\\.(Rmd|r|R|md|tex|.{1,4})$)")
  extension <- unlist(partsOfName)[3]
  # What function to open the file with
  thingToDo <-
    if (tolower(extension) %in% c(".rda", ".csv", ".rdata",".txt")) {
      function(file)
        mosaic::read.file(file, header=header, na.strings=na.strings)
    } else if (tolower(extension) %in% c(".r", ".rmd", ".rpres")) {
      .openInEditor
    }

  # Look at the repositories in order, using the first that works.
  whichFile <- ""
  for (site in .ourWebServers) {
    fullname <- paste0(site,file)
    if (!RCurl::url.exists(fullname))
      next
    else {
      whichFile <- fullname
      break
    }
  }
  if( whichFile == "") error("No such file found in course server directories.")

  # Do the right thing: read in data or open in editor
  thingToDo(whichFile)
}
#' @export
edit_web_file <- our_file
#'
#' Utility function
#' assumes <location> has been pre-checked as existing
.openInEditor <- function(location) {
  contents <- RCurl::getURL(location)
  fname <- basename(location)
  partsOfName <- stringr::str_match_all(fname,
                                        "(^.+)(\\.(Rmd|r|R|md|tex|.{1,4})$)")
  filename <- unlist(partsOfName)[2]
  extension <- unlist(partsOfName)[3]
  tmpname <- tempfile(pattern=paste0(filename,"---"), fileext=extension)
  cat(contents,file=tmpname) # write contents to temporary file
  file.edit(tmpname)
  message("Remember to save as ",
          paste0(filename,extension),
          " in your own folder. Until you do, it's just temporary.")
  invisible(tmpname)
}

